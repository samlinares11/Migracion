DROP TABLE IF EXISTS `cliente`;

CREATE TABLE `cliente` (
  `id` mediumint(8) unsigned NOT NULL auto_increment,
  `nombre` varchar(255) default NULL,
  `region` varchar(50) default NULL,
  `email` varchar(255) default NULL,
  PRIMARY KEY (`id`)
) AUTO_INCREMENT=1;

INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Melodie Schwartz","Île-de-France","integer.aliquam@icloud.com"),
  ("Lewis Velasquez","Lambayeque","tempus@google.net"),
  ("Conan Wilcox","Cherkasy oblast","iaculis@outlook.com"),
  ("Lillian Brown","Gujarat","et.magnis@hotmail.org"),
  ("Drew Deleon","Western Visayas","lacus.aliquam@outlook.com"),
  ("Oren Newman","South Island","lectus@aol.com"),
  ("Joy Dillard","Huádōng","tellus.imperdiet@outlook.net"),
  ("Stacy Glass","California","sem.magna@protonmail.org"),
  ("Lila Schneider","Auvergne","fusce.dolor@yahoo.couk"),
  ("Harlan Randolph","Baja California","a.enim@yahoo.org");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Wang Caldwell","Khmelnytskyi oblast","purus@outlook.com"),
  ("Zoe Vang","Huila","nunc.laoreet@aol.couk"),
  ("Trevor Miller","Niger","nonummy@google.org"),
  ("Aphrodite Gonzalez","Ontario","in@yahoo.couk"),
  ("Hilda Mendoza","Hidalgo","cursus@yahoo.com"),
  ("Penelope Donovan","Central Region","nunc.ullamcorper.eu@hotmail.couk"),
  ("Paki Mccray","Abruzzo","euismod@aol.org"),
  ("Jackson Cox","Tasmania","malesuada.id@protonmail.couk"),
  ("Raven Hart","Brandenburg","cursus.luctus@yahoo.couk"),
  ("Hasad Fowler","Ceará","natoque.penatibus@google.couk");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Vance Britt","Gyeonggi","feugiat.sed@aol.net"),
  ("Alec Witt","Provence-Alpes-Côte d'Azur","luctus@protonmail.edu"),
  ("Fatima Kramer","Tarapacá","ac.fermentum@yahoo.net"),
  ("Vivian Patrick","Đà Nẵng","etiam@outlook.net"),
  ("Ferris Best","West Papua","neque@google.ca"),
  ("Joel Jarvis","Punjab","tincidunt@google.edu"),
  ("Gloria May","Swiętokrzyskie","mi.ac@google.net"),
  ("Audrey Kidd","Dōngběi","vulputate.ullamcorper@hotmail.couk"),
  ("Maris Craft","Castilla y León","nec.orci.donec@hotmail.com"),
  ("Nyssa Howe","Tuyên Quang","libero@protonmail.com");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Natalie Cook","Khyber Pakhtoonkhwa","nisi.aenean@protonmail.couk"),
  ("Rama Golden","Rheinland-Pfalz","tincidunt@aol.ca"),
  ("Eaton Hoffman","Northern Mindanao","posuere.cubilia@outlook.couk"),
  ("Noelle Harrison","Saarland","mauris.sit@google.net"),
  ("Briar Hodges","Nariño","eget.ipsum@aol.edu"),
  ("Zachary Bass","Stockholms län","nibh.vulputate@outlook.org"),
  ("Charissa Alvarez","Burgenland","commodo@aol.ca"),
  ("Brenda Saunders","Lào Cai","sed.eu.eros@yahoo.com"),
  ("Risa Watts","Kaduna","orci.adipiscing@google.edu"),
  ("Carter Durham","Dalarnas län","nascetur.ridiculus@protonmail.ca");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Baker Mcdowell","Free State","non.hendrerit@outlook.com"),
  ("Natalie Hamilton","Oklahoma","semper@icloud.couk"),
  ("Oscar Burns","South Jeolla","morbi.accumsan@hotmail.couk"),
  ("Leonard Sosa","Antwerpen","neque.non@outlook.net"),
  ("Buckminster Puckett","Puno","a.enim@protonmail.net"),
  ("Wang Hobbs","Huáběi","cras.vulputate@hotmail.org"),
  ("Conan Langley","Bali","feugiat@protonmail.edu"),
  ("Hyatt Hendrix","Şanlıurfa","nonummy.fusce.fermentum@aol.couk"),
  ("Bernard Chavez","Morelos","velit@yahoo.net"),
  ("Rhonda Woodard","Andhra Pradesh","iaculis.odio@yahoo.couk");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Kaye Booth","Sinaloa","mattis.cras@outlook.edu"),
  ("Mikayla Donaldson","Opolskie","iaculis.lacus@hotmail.com"),
  ("Salvador Gentry","Azad Kashmir","donec.tempor@protonmail.net"),
  ("Len Maldonado","North Island","non@icloud.net"),
  ("Florence Mills","Special Capital Region of Jakarta","augue.eu@hotmail.edu"),
  ("Martena Montgomery","Burgenland","pulvinar.arcu@protonmail.net"),
  ("Michael Jefferson","Coquimbo","eu.tellus@yahoo.net"),
  ("Joseph Thornton","Connecticut","dignissim.lacus.aliquam@yahoo.ca"),
  ("Risa Jennings","Leinster","in.lorem@protonmail.com"),
  ("Fallon Kane","Illinois","eros.nec@icloud.org");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Vivian Bradley","Jönköpings län","quam.vel.sapien@aol.org"),
  ("Katelyn Wiggins","South Chungcheong","mi.eleifend@aol.couk"),
  ("Lillith Holden","Utrecht","cras.lorem.lorem@yahoo.ca"),
  ("Merritt Riddle","Limburg","hendrerit.a@icloud.ca"),
  ("Philip Cook","Meta","consectetuer@hotmail.ca"),
  ("Doris Rogers","Đồng Tháp","ac.sem@icloud.ca"),
  ("Axel Roth","Nord-Pas-de-Calais","rutrum.eu.ultrices@hotmail.edu"),
  ("Lucian Head","Kocaeli","varius.et.euismod@aol.net"),
  ("Nehru Fuentes","Central Java","ante.nunc@hotmail.edu"),
  ("Velma Green","Leinster","aenean@google.ca");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Valentine Gibbs","Cartago","mauris.morbi@outlook.couk"),
  ("Caleb Horne","Sindh","nisi.nibh.lacinia@outlook.net"),
  ("Carter Sullivan","West Region","lorem.ac@outlook.couk"),
  ("Ronan Mccoy","Noord Holland","elit@icloud.org"),
  ("Patience Wheeler","Guaviare","egestas.urna@google.edu"),
  ("Anne Merrill","Santa Catarina","id.risus.quis@hotmail.edu"),
  ("Lester Hubbard","Basilicata","ultrices.vivamus@yahoo.com"),
  ("Allen Joseph","Jeju","ut.dolor.dapibus@protonmail.com"),
  ("Todd Nelson","Sardegna","pede.sagittis@yahoo.couk"),
  ("Ramona Duran","Flevoland","magna@protonmail.couk");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Dylan Mcclain","Brandenburg","nec.diam@icloud.com"),
  ("Paula Mathis","Luik","ante.vivamus@icloud.edu"),
  ("Bryar Swanson","Sonora","erat@icloud.couk"),
  ("Chaney Mckay","Borno","mauris.rhoncus@outlook.ca"),
  ("Darius Rush","Hồ Chí Minh City","nascetur.ridiculus.mus@aol.com"),
  ("Elton Roman","Navarra","dignissim.pharetra@google.org"),
  ("Lara Hernandez","Pernambuco","tincidunt.congue@hotmail.couk"),
  ("Logan Sheppard","Connacht","diam.vel@hotmail.couk"),
  ("Dillon Paul","Rio Grande do Sul","imperdiet.ullamcorper@yahoo.ca"),
  ("Ria Fitzgerald","Santander","molestie@aol.couk");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Igor Freeman","Lagos","vitae.orci.phasellus@google.couk"),
  ("Simone Noble","Ulster","metus.sit.amet@icloud.ca"),
  ("Moana Marquez","Kemerovo Oblast","malesuada@hotmail.ca"),
  ("Madeson Murphy","Ulyanovsk Oblast","rhoncus.id@google.couk"),
  ("Maile Brady","Junín","ipsum@icloud.com"),
  ("Sydnee Woodard","Lagos","eu.lacus@icloud.org"),
  ("Rebekah Frye","Bayern","curabitur.consequat@hotmail.ca"),
  ("Carlos Wilson","Henegouwen","malesuada.malesuada@hotmail.edu"),
  ("Leah Levy","Mazowieckie","quis.accumsan@yahoo.org"),
  ("Evan Berger","Puntarenas","euismod.in@protonmail.net");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Joelle Allen","Gilgit Baltistan","per@protonmail.com"),
  ("Zachery Oneil","Innlandet","curabitur.ut.odio@aol.com"),
  ("Maryam Gates","Xīběi","sem.egestas@hotmail.org"),
  ("Keiko Manning","Puno","nulla.cras@outlook.com"),
  ("Oprah Delaney","Selkirkshire","ac@google.com"),
  ("Cooper Case","Tyrol","donec.vitae@aol.ca"),
  ("Macy Fulton","South Jeolla","consequat@google.ca"),
  ("Halla Velasquez","Aragón","orci.ut@protonmail.ca"),
  ("Charlotte Oneal","Banten","vestibulum.mauris@icloud.net"),
  ("Pearl Sherman","Tolima","quis.turpis@aol.couk");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Tashya Valentine","Soccsksargen","nascetur.ridiculus.mus@hotmail.edu"),
  ("Elvis Irwin","Los Ríos","et.nunc.quisque@icloud.com"),
  ("Gloria Rios","Waals-Brabant","eget.volutpat@google.org"),
  ("Imelda Lindsey","Basse-Normandie","at.auctor.ullamcorper@icloud.couk"),
  ("Reece Shaffer","Şanlıurfa","vitae@hotmail.org"),
  ("Amethyst Ellison","Waals-Brabant","metus.in.lorem@aol.com"),
  ("Lael Morin","Basilicata","interdum.libero@aol.com"),
  ("Keelie Kelly","Punjab","tellus.suspendisse@icloud.couk"),
  ("Laura Brady","Lviv oblast","phasellus@protonmail.ca"),
  ("Buffy Cobb","Tasmania","dui@protonmail.ca");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Michael Swanson","Innlandet","dictum.sapien.aenean@outlook.org"),
  ("Alexandra Galloway","Quảng Bình","sed.malesuada.augue@protonmail.com"),
  ("Hilary Vaughan","Västra Götalands län","interdum.ligula@icloud.ca"),
  ("Benedict Farley","Leinster","phasellus@hotmail.net"),
  ("Nasim Gay","KwaZulu-Natal","at.sem@aol.org"),
  ("Astra Dominguez","Alsace","sapien.aenean.massa@outlook.com"),
  ("Drake Dalton","Vestfold og Telemark","proin@yahoo.org"),
  ("Paul Colon","Borno","nulla.aliquet.proin@aol.couk"),
  ("Isaac Fields","Melilla","nunc@icloud.edu"),
  ("Sigourney Reed","Sardegna","tristique@google.edu");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Tate Carlson","Innlandet","ac.mattis@protonmail.org"),
  ("Tana Mullen","South Chungcheong","eu.nulla@protonmail.com"),
  ("Thaddeus Hall","La Libertad","suspendisse.tristique@icloud.org"),
  ("Ayanna Rivas","Chocó","libero.proin@google.com"),
  ("Blake Francis","KwaZulu-Natal","sociis.natoque.penatibus@icloud.ca"),
  ("Wallace Murray","North Island","odio.vel@hotmail.org"),
  ("Libby Benson","Vienna","vitae.odio.sagittis@aol.edu"),
  ("Micah Rowland","Calabarzon","adipiscing.ligula@aol.net"),
  ("Britanni Fletcher","Lima","aliquam.eu@icloud.net"),
  ("Mollie Juarez","North Region","viverra.maecenas.iaculis@aol.ca");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Hayes Cruz","Styria","cursus.non.egestas@google.ca"),
  ("Rhoda Chapman","Anambra","ultrices.vivamus@outlook.org"),
  ("Briar Knowles","North Gyeongsang","mollis.non.cursus@google.ca"),
  ("Dorian Murphy","Cartago","luctus.sit@hotmail.org"),
  ("Molly Ward","Västra Götalands län","dui@outlook.net"),
  ("Silas Wells","Caquetá","luctus.curabitur.egestas@icloud.org"),
  ("Asher Paul","Cartago","neque.nullam@aol.com"),
  ("Beau Franks","National Capital Region","id.ante@outlook.com"),
  ("Tiger Mcintyre","Pondicherry","non.justo@outlook.com"),
  ("Hannah O'connor","East Region","fusce.mi@icloud.net");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Nolan Mcguire","Konya","eu.placerat@google.edu"),
  ("Valentine Woods","Nunavut","lorem.luctus.ut@protonmail.couk"),
  ("Blossom Knapp","Loreto","non.magna.nam@protonmail.edu"),
  ("Laura Sanford","Utrecht","id.magna.et@protonmail.edu"),
  ("Teagan Terrell","Gyeonggi","fusce.mi.lorem@yahoo.org"),
  ("Ira Jackson","Dumfriesshire","mollis@icloud.com"),
  ("Bevis Graham","Adana","nulla.cras@google.org"),
  ("Blake Fleming","Stockholms län","parturient@aol.couk"),
  ("Elton Reid","Riau","cum.sociis.natoque@google.couk"),
  ("Hermione Livingston","Tarapacá","ut.ipsum@google.couk");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Rowan Mccullough","Tarapacá","ut@hotmail.org"),
  ("Jermaine England","Castilla y León","sodales.at@hotmail.edu"),
  ("Kay Mitchell","Leningrad Oblast","magna.nec@icloud.ca"),
  ("Ralph Kramer","Stockholms län","pellentesque@outlook.couk"),
  ("Serena Good","Valle d'Aosta","massa.suspendisse@aol.ca"),
  ("Gannon Crosby","Connacht","nunc.ullamcorper@protonmail.com"),
  ("Isabelle Randolph","Niger","vulputate@yahoo.ca"),
  ("Cameran Gould","Murmansk Oblast","ornare.in@hotmail.net"),
  ("Dennis Lamb","Toscana","enim.condimentum.eget@google.edu"),
  ("Ebony Bender","Donetsk oblast","tincidunt.nunc.ac@google.edu");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Christen Steele","Lima","mauris@icloud.couk"),
  ("Shannon Sweeney","San José","velit@icloud.net"),
  ("Kirsten Reid","Antofagasta","odio.aliquam@outlook.ca"),
  ("Pamela Pitts","Lambayeque","ut.pellentesque.eget@aol.com"),
  ("Fletcher Reese","Sutherland","dictum.augue@outlook.org"),
  ("Eve Carver","Provence-Alpes-Côte d'Azur","habitant@protonmail.com"),
  ("Lance Gould","Piemonte","eu@outlook.couk"),
  ("Vincent Livingston","Aceh","adipiscing@icloud.com"),
  ("Carter Huffman","Dōngběi","varius.ultrices@aol.edu"),
  ("Yuli Cannon","Iowa","massa.non@yahoo.com");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Regan Hester","Bayern","ac.facilisis@aol.ca"),
  ("Berk Huff","West Region","et.magnis@protonmail.net"),
  ("Sheila Dickerson","Valparaíso","consectetuer.rhoncus.nullam@outlook.couk"),
  ("Ingrid Castaneda","South Chungcheong","erat.neque@google.org"),
  ("Russell Richmond","Illes Balears","non@aol.com"),
  ("Shelly Gillespie","Jönköpings län","quam.elementum@aol.ca"),
  ("Indigo Donovan","California","id.erat@outlook.net"),
  ("Angela Hansen","Namen","mi.pede@hotmail.ca"),
  ("Paki Vasquez","Minas Gerais","aliquet@google.org"),
  ("Shelly Jenkins","Västra Götalands län","praesent@hotmail.net");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("John Fields","Odessa oblast","ac.turpis.egestas@aol.couk"),
  ("Raymond Porter","Sląskie","id@yahoo.net"),
  ("Mohammad Conway","Western Visayas","consectetuer@hotmail.couk"),
  ("Graiden Fry","Lazio","ornare.elit@yahoo.com"),
  ("Moana Garrett","Alabama","maecenas.iaculis@yahoo.org"),
  ("Merritt Salazar","Eastern Visayas","libero.integer.in@protonmail.edu"),
  ("Alisa Hayes","Nordrhein-Westphalen","nullam@aol.com"),
  ("Cairo Duke","Amur Oblast","cursus.in@hotmail.couk"),
  ("Honorato Sweet","Leinster","pede@icloud.edu"),
  ("Lysandra Mcbride","South Island","luctus.aliquet.odio@outlook.couk");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Rama Rollins","Coquimbo","praesent.eu@hotmail.net"),
  ("Hillary Forbes","Nunavut","convallis.est@google.com"),
  ("Joseph Travis","Östergötlands län","phasellus.dapibus.quam@icloud.edu"),
  ("Ann Jensen","Ogun","dolor@outlook.couk"),
  ("Geraldine Gillespie","Fife","iaculis.lacus@google.com"),
  ("Scott Rios","Haute-Normandie","nulla@aol.edu"),
  ("Emerald Long","Gävleborgs län","est@icloud.org"),
  ("Fuller Downs","Soccsksargen","vel.venenatis.vel@protonmail.ca"),
  ("Mikayla Yang","Flevoland","facilisis.non.bibendum@icloud.couk"),
  ("Evan Stokes","Bauchi","elit.pharetra@icloud.net");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Whitney Ratliff","South Australia","quam@hotmail.edu"),
  ("Adria Potts","Cusco","ac.nulla@protonmail.net"),
  ("Rigel Bryant","East Region","amet.risus.donec@outlook.org"),
  ("Moses Yates","West Region","iaculis.odio@outlook.ca"),
  ("Hoyt Roberson","Western Australia","eleifend@yahoo.net"),
  ("Leonard Potter","Quebec","nulla.donec@outlook.edu"),
  ("Allegra Cobb","Lima","dolor.nulla.semper@protonmail.com"),
  ("Xaviera French","İzmir","habitant@protonmail.edu"),
  ("Caldwell Ramirez","Tasmania","dolor.tempus@google.ca"),
  ("Hoyt Battle","FATA","elementum@icloud.com");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Teegan Branch","Tuyên Quang","quis.diam.luctus@protonmail.edu"),
  ("Rowan Franks","Gävleborgs län","volutpat.nunc@outlook.couk"),
  ("Porter Vaughan","Lower Austria","amet.faucibus@google.net"),
  ("Rebekah Joyce","Western Australia","magnis.dis@google.edu"),
  ("Ila Cummings","Araucanía","vulputate@hotmail.net"),
  ("Velma Fox","South Island","aliquam.nec@protonmail.org"),
  ("Hedda Matthews","Podlaskie","imperdiet.ullamcorper@protonmail.ca"),
  ("Joelle Rivera","Los Lagos","est.nunc.laoreet@google.org"),
  ("Aladdin Patel","Daman and Diu","sapien.imperdiet@icloud.couk"),
  ("Astra Pugh","Zamboanga Peninsula","velit.eu.sem@icloud.net");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Ahmed Kinney","Zhōngnán","varius.ultrices.mauris@icloud.com"),
  ("Chava Smith","Basse-Normandie","vulputate.eu@protonmail.edu"),
  ("Jordan Golden","Friesland","nam.porttitor.scelerisque@protonmail.org"),
  ("Adrian Stanley","Huáběi","amet@protonmail.ca"),
  ("Kato Gibbs","Istanbul","dolor.elit@google.org"),
  ("Christen Lawson","West Bengal","sit@hotmail.com"),
  ("Amery Case","Voronezh Oblast","duis.at@outlook.edu"),
  ("Jordan Baldwin","South Island","tincidunt.pede@protonmail.edu"),
  ("Kylan Mcguire","South Australia","sagittis.felis@aol.com"),
  ("Cedric Fletcher","Zhōngnán","primis.in.faucibus@aol.com");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Piper Strickland","Lampung","dolor.dapibus.gravida@google.com"),
  ("Iris Morrow","Languedoc-Roussillon","nam.ac@icloud.org"),
  ("Ocean Davenport","Arequipa","luctus.ut@icloud.com"),
  ("Gavin O'brien","Khyber Pakhtoonkhwa","laoreet.ipsum@yahoo.ca"),
  ("Aladdin Keller","Orenburg Oblast","neque.vitae.semper@outlook.edu"),
  ("Elijah Briggs","Gorontalo","ligula.nullam.feugiat@hotmail.edu"),
  ("Nicholas Vega","North Chungcheong","a.sollicitudin@icloud.net"),
  ("Quintessa Tucker","Limburg","natoque.penatibus@hotmail.edu"),
  ("Tatum Pittman","North Chungcheong","nunc.ut@yahoo.net"),
  ("Stone Hill","North Maluku","vestibulum.neque@protonmail.com");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Stewart Haynes","Khyber Pakhtoonkhwa","ac.mattis@yahoo.com"),
  ("Clark Hancock","Maluku","tristique.pellentesque@protonmail.couk"),
  ("Kaseem Mcgee","Ninh Bình","mi@icloud.org"),
  ("Aspen Delgado","Punjab","morbi.accumsan@aol.org"),
  ("Whitney Bridges","Gangwon","vitae@yahoo.ca"),
  ("Kylynn Velez","Punjab","eget@yahoo.com"),
  ("Vernon Gill","Gujarat","id.ante@protonmail.ca"),
  ("Zeus Buchanan","South Island","adipiscing.ligula@aol.ca"),
  ("Maggie Rivera","Norte de Santander","erat@protonmail.edu"),
  ("Reece Fry","Western Cape","etiam@outlook.couk");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Emerson Pennington","Gilgit Baltistan","elementum.dui@google.edu"),
  ("Ray Nash","Hessen","suspendisse.tristique.neque@google.com"),
  ("Herrod Cotton","Prince Edward Island","ultrices.posuere@protonmail.ca"),
  ("Darryl Olson","Free State","erat.vitae@hotmail.com"),
  ("Lillian Lynch","Volyn oblast","lacus.etiam@hotmail.edu"),
  ("Jacqueline Wilkinson","Xīběi","odio.tristique@protonmail.com"),
  ("Caesar Cooper","Khyber Pakhtoonkhwa","sed.orci@hotmail.couk"),
  ("Fuller Bowman","Antalya","sodales.purus@outlook.edu"),
  ("Pearl Soto","Arica y Parinacota","congue.turpis@protonmail.ca"),
  ("Zachary Navarro","Connacht","dui@aol.net");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Ciara Pratt","South Kalimantan","ligula@outlook.couk"),
  ("Theodore Norris","Hessen","suspendisse.sed@hotmail.net"),
  ("Damon Deleon","Norfolk","diam.eu.dolor@google.couk"),
  ("Gareth Saunders","Mpumalanga","eu.neque@google.ca"),
  ("Martha Stafford","Sokoto","magnis.dis@yahoo.couk"),
  ("Melodie Moran","Connacht","nullam.vitae@yahoo.edu"),
  ("Isadora Dennis","Texas","fusce.diam@yahoo.couk"),
  ("Phillip Harper","Imo","pede.cum.sociis@hotmail.ca"),
  ("Cole Glass","Central Region","felis.orci@hotmail.org"),
  ("Isaiah Chang","Jeju","nulla.tincidunt.neque@icloud.net");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Colin Rosa","Hatay","neque.nullam.ut@google.couk"),
  ("Calvin Mack","Maharastra","morbi.vehicula@outlook.net"),
  ("Halla Bauer","Rostov Oblast","sit.amet@outlook.org"),
  ("Caryn Morgan","Kujawsko-pomorskie","amet.risus.donec@icloud.net"),
  ("Camille Joseph","Dōngběi","ligula.aenean@hotmail.couk"),
  ("Freya Mckay","Ulster","aenean.massa@protonmail.edu"),
  ("Forrest Mclean","Kentucky","nunc.quis.arcu@icloud.ca"),
  ("Hashim Galloway","Picardie","praesent.eu.nulla@google.ca"),
  ("Jillian Rocha","Minas Gerais","arcu@yahoo.ca"),
  ("Solomon Hanson","Ancash","euismod.mauris@icloud.edu");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Jared Clay","Friesland","diam.pellentesque.habitant@protonmail.com"),
  ("Colton Kelley","Arauca","egestas.a.scelerisque@aol.ca"),
  ("Darryl Riley","Saskatchewan","sed.et@aol.ca"),
  ("Eagan Fischer","Zhytomyr oblast","ac.libero@protonmail.couk"),
  ("Kyle Mack","Oryol Oblast","torquent.per@hotmail.edu"),
  ("Kaitlin Sargent","Stockholms län","tempor.diam@google.org"),
  ("Ivan Blake","Queensland","id.risus@aol.edu"),
  ("Josephine Barton","South Chungcheong","eu.odio@yahoo.edu"),
  ("Rogan Buchanan","Wyoming","facilisis.facilisis@google.ca"),
  ("Cameran Head","Goiás","massa.mauris@hotmail.ca");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Herrod Warren","Munster","donec.felis@aol.ca"),
  ("Basil Hunter","Chihuahua","pellentesque@protonmail.edu"),
  ("Rama Juarez","Oaxaca","elit@outlook.edu"),
  ("Alexis Carey","Munster","dolor.nulla.semper@hotmail.com"),
  ("Malcolm Dixon","Magadan Oblast","phasellus@outlook.org"),
  ("Declan Stuart","Namen","torquent.per@icloud.edu"),
  ("Hoyt Mathis","South Gyeongsang","eros@hotmail.ca"),
  ("Nerea Graves","Drenthe","vitae.odio@google.ca"),
  ("Carl Coffey","Nebraska","vestibulum.lorem@hotmail.couk"),
  ("Rooney Browning","Limpopo","sed.nulla@outlook.net");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Mia Lowe","Ancash","eu.eros@yahoo.org"),
  ("Aline Dale","South Chungcheong","phasellus.dapibus.quam@protonmail.com"),
  ("Rinah Pennington","Umbria","etiam.gravida@outlook.org"),
  ("Rina Lambert","Northern Cape","ac.facilisis@icloud.net"),
  ("Rajah Leach","Caldas","cubilia.curae@outlook.edu"),
  ("Irma Cervantes","Puglia","condimentum.donec@hotmail.com"),
  ("Chaney Figueroa","Huádōng","odio@hotmail.net"),
  ("Ulric Dennis","Manipur","nec.urna@hotmail.net"),
  ("Elijah Riley","Lower Austria","molestie.sed@protonmail.org"),
  ("Valentine Garrison","Berlin","vel.sapien.imperdiet@aol.com");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Brian Leblanc","Vlaams-Brabant","orci@outlook.edu"),
  ("Uriah Travis","Central Region","eget.odio@hotmail.net"),
  ("Abel Burke","Central Region","ligula.nullam@yahoo.couk"),
  ("Ava Leonard","Oost-Vlaanderen","donec.porttitor@hotmail.com"),
  ("Tamekah Robles","Prince Edward Island","aliquam.iaculis@yahoo.ca"),
  ("Xavier Burris","Central Java","sit.amet@aol.com"),
  ("Theodore Garner","Małopolskie","vulputate.risus@outlook.ca"),
  ("Lucian Solomon","Northern Mindanao","augue.eu@icloud.net"),
  ("Whoopi Gould","Swiętokrzyskie","faucibus@protonmail.edu"),
  ("Berk Mayer","Upper Austria","libero@google.ca");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Jade Benton","Kogi","tellus.phasellus@protonmail.ca"),
  ("Emmanuel Hickman","Viken","a@protonmail.com"),
  ("Jordan Benjamin","Nova Scotia","malesuada.malesuada.integer@outlook.com"),
  ("Branden Mcintyre","Oslo","nibh@hotmail.org"),
  ("Amy Gilmore","North Region","lacus@aol.com"),
  ("Owen Schwartz","Orkney","vitae@aol.ca"),
  ("Lenore Soto","Penza Oblast","sem.molestie@hotmail.net"),
  ("Travis Pacheco","New Brunswick","dui.cras.pellentesque@hotmail.org"),
  ("Justina Maynard","Vlaams-Brabant","augue.scelerisque@yahoo.couk"),
  ("Constance Noel","Phú Yên","eu.erat.semper@google.com");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Katelyn Middleton","Santa Catarina","curabitur.dictum.phasellus@icloud.com"),
  ("Randall Fuller","Aragón","ipsum.ac@yahoo.com"),
  ("Paula Ewing","East Nusa Tenggara","accumsan.laoreet@hotmail.com"),
  ("Abbot Jones","KwaZulu-Natal","neque.in.ornare@yahoo.org"),
  ("Nigel Chapman","Northwest Territories","nisi.nibh@icloud.ca"),
  ("Cleo Noble","Flevoland","cras.lorem.lorem@aol.net"),
  ("Whitney Crosby","Morelos","vulputate.velit@aol.org"),
  ("Jaime Mueller","Lubuskie","eleifend.cras.sed@outlook.couk"),
  ("Perry Cross","Midi-Pyrénées","sem.ut@hotmail.com"),
  ("Nissim Marsh","West Sumatra","malesuada.fringilla@protonmail.ca");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Cade Knox","Lima","at@protonmail.couk"),
  ("Hannah Pate","Central Luzon","montes.nascetur@aol.ca"),
  ("Callie Pitts","Maranhão","enim.etiam.gravida@yahoo.couk"),
  ("Patrick Rios","Los Ríos","donec.vitae.erat@yahoo.ca"),
  ("Mara Camacho","Santa Catarina","in.magna@google.net"),
  ("Keith Kane","Meghalaya","eu@yahoo.ca"),
  ("Shad Hobbs","Viken","nisi.magna@aol.edu"),
  ("Thomas Ross","Idaho","accumsan.sed.facilisis@icloud.edu"),
  ("Declan Clarke","North-East Region","integer.id@aol.net"),
  ("Logan Mccormick","Zhōngnán","ipsum.primis@aol.ca");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Amethyst Garrett","Wielkopolskie","penatibus@yahoo.edu"),
  ("Uma Combs","Bolívar","dapibus.gravida.aliquam@outlook.couk"),
  ("Hayfa Conway","Salzburg","consequat@aol.net"),
  ("Malcolm Vaughn","Rio de Janeiro","in@hotmail.com"),
  ("Elmo Carroll","Aragón","dolor.quisque.tincidunt@google.couk"),
  ("Jordan Dejesus","North Region","natoque.penatibus@protonmail.couk"),
  ("Bianca Larson","Podkarpackie","vel.arcu@hotmail.org"),
  ("Claudia Mcgee","Cartago","luctus.et.ultrices@icloud.couk"),
  ("Tad Rosales","Tuyên Quang","nascetur.ridiculus.mus@yahoo.com"),
  ("Imogene Payne","Lower Austria","morbi.tristique@icloud.com");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Jameson Gill","Cartago","pellentesque@hotmail.ca"),
  ("Timothy Waters","Khmelnytskyi oblast","sed.auctor@aol.com"),
  ("Keaton Case","Aisén","turpis.nulla@google.couk"),
  ("Dorothy Dillon","Northern Territory","vehicula.risus@outlook.net"),
  ("Patience Barnes","Meghalaya","in.consequat@aol.couk"),
  ("Eagan Chaney","Katsina","volutpat.nulla.dignissim@google.couk"),
  ("Hayley Rivas","Gilgit Baltistan","orci.sem.eget@icloud.edu"),
  ("Brent Lawrence","Australian Capital Territory","mauris.vestibulum.neque@yahoo.com"),
  ("Keith Mcfadden","British Columbia","faucibus.id.libero@yahoo.couk"),
  ("Hedy Lambert","Lubelskie","dolor@outlook.org");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Raven Cervantes","Punjab","massa.lobortis.ultrices@yahoo.net"),
  ("Yuri Shaffer","Paraná","morbi.tristique.senectus@icloud.org"),
  ("Graham Higgins","San Luis Potosí","placerat.orci@outlook.org"),
  ("Sopoline Randolph","Maluku","eu.accumsan@hotmail.couk"),
  ("Dawn Mcpherson","An Giang","erat.vivamus.nisi@outlook.edu"),
  ("Diana Pope","Quảng Ngãi","vestibulum.nec@hotmail.couk"),
  ("Regan Kent","Antwerpen","elit.pharetra@aol.org"),
  ("Talon Buchanan","Oxfordshire","consequat.purus.maecenas@hotmail.net"),
  ("Kamal Carson","Victoria","nulla@icloud.couk"),
  ("Dean Shepard","Gloucestershire","placerat.augue@yahoo.couk");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Mason Palmer","Goa","elit.pretium@hotmail.edu"),
  ("Odette Greene","Kursk Oblast","integer@protonmail.com"),
  ("Rooney Fitzpatrick","Lorraine","sit.amet@yahoo.edu"),
  ("Ethan Hensley","Kogi","auctor.odio@protonmail.org"),
  ("Quail Stevens","Atlántico","vehicula.risus@yahoo.couk"),
  ("Eric Wheeler","Berlin","amet@aol.net"),
  ("Porter Cummings","Central Region","placerat.augue@outlook.com"),
  ("Emma Sampson","North Jeolla","dolor@yahoo.org"),
  ("August Pacheco","Stockholms län","suspendisse.dui@outlook.com"),
  ("Joelle Duncan","Northern Cape","dictum.eleifend@icloud.org");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Lunea Randolph","Cundinamarca","sagittis.nullam.vitae@protonmail.org"),
  ("Alden Shaffer","Vestland","ornare@hotmail.com"),
  ("Michelle Edwards","South Kalimantan","ut.sem@icloud.org"),
  ("Ray Medina","Biobío","non.dui@hotmail.edu"),
  ("Adele Stone","Navarra","posuere.cubilia@protonmail.net"),
  ("Walter Hammond","Rio Grande do Sul","in.at.pede@yahoo.edu"),
  ("Nissim Petersen","Kujawsko-pomorskie","nullam.vitae.diam@outlook.couk"),
  ("Barclay Young","Maranhão","quisque.tincidunt@google.edu"),
  ("Kibo Orr","New Brunswick","congue@protonmail.edu"),
  ("Echo Macdonald","Chelyabinsk Oblast","sem@outlook.com");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Jack Leach","Georgia","vestibulum.lorem@outlook.org"),
  ("Desirae Brock","Puno","nunc.laoreet@aol.couk"),
  ("Jaquelyn Delgado","Newfoundland and Labrador","non.leo@outlook.org"),
  ("Nichole Burt","Cao Bằng","nulla.tincidunt.neque@google.ca"),
  ("Jolie Gibson","Piemonte","nibh.enim@google.couk"),
  ("Stone Boyd","Lạng Sơn","integer.tincidunt@icloud.com"),
  ("Jin Russo","Coquimbo","sollicitudin.a.malesuada@outlook.net"),
  ("Holmes O'donnell","Innlandet","ornare.sagittis.felis@aol.couk"),
  ("Dane Strong","Andalucía","cursus.et@protonmail.net"),
  ("Harding Hurley","Amur Oblast","mauris.sit@outlook.net");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Cassidy Garrett","Central Kalimantan","cras@google.net"),
  ("Ezra Mathis","Ogun","tristique.pharetra.quisque@outlook.edu"),
  ("Alexander Crosby","Northern Mindanao","aliquam.eros@icloud.org"),
  ("Angela Santiago","Vinnytsia oblast","eget.ipsum.donec@aol.org"),
  ("Oscar Faulkner","Canarias","curabitur.vel.lectus@aol.com"),
  ("Lara Bradley","Tasmania","elementum@hotmail.org"),
  ("Dillon Mitchell","Jönköpings län","arcu@yahoo.edu"),
  ("Allen Vincent","Veracruz","neque@yahoo.ca"),
  ("Karly Oliver","Leinster","nibh.phasellus@aol.net"),
  ("Karen Osborn","Tula Oblast","at.lacus@google.com");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Gemma Nielsen","Oost-Vlaanderen","pede.nec@yahoo.edu"),
  ("Simon Lester","Punjab","imperdiet.dictum@aol.edu"),
  ("Price Sanford","Alajuela","magna@yahoo.net"),
  ("Haley Christensen","West Region","malesuada.fames@hotmail.com"),
  ("Tanya Sweet","Guerrero","tellus.nunc@hotmail.ca"),
  ("George Rollins","Limón","enim@hotmail.edu"),
  ("Kitra Acevedo","Gävleborgs län","pharetra.nam@yahoo.couk"),
  ("Nell Gray","łódzkie","morbi.neque@google.edu"),
  ("Serena Ochoa","Antwerpen","tortor.integer.aliquam@yahoo.org"),
  ("Imogene Bender","Leinster","neque.nullam.nisl@aol.net");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Shellie Burch","Munster","orci.luctus.et@outlook.net"),
  ("Brynn Shields","Western Australia","a.arcu@aol.couk"),
  ("Phyllis Mullen","Chhattisgarh","ultricies.adipiscing@outlook.net"),
  ("Kerry Bush","Bayern","fusce.aliquam@aol.ca"),
  ("Colby Woodward","Davao Region","blandit@icloud.edu"),
  ("Driscoll Bass","Pennsylvania","ut.semper@icloud.net"),
  ("Fuller Herman","Maranhão","hendrerit@google.net"),
  ("Axel Yang","Jönköpings län","sed.eu@aol.ca"),
  ("Nadine Blackwell","Antwerpen","mauris.magna@yahoo.org"),
  ("Daquan Jefferson","East Region","suspendisse.tristique@protonmail.edu");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Claire Cunningham","North Gyeongsang","cursus.a.enim@icloud.com"),
  ("Lance Lambert","La Rioja","a.ultricies@outlook.com"),
  ("Plato Wagner","Cauca","eget@protonmail.couk"),
  ("Xanthus Aguilar","Sokoto","nisl.elementum.purus@icloud.ca"),
  ("Megan Henson","Quảng Ninh","mollis.vitae@yahoo.org"),
  ("Owen Garrett","Cundinamarca","vitae.erat@google.edu"),
  ("Dana Dale","South Chungcheong","maecenas.iaculis@hotmail.edu"),
  ("Nasim Mendez","Östergötlands län","iaculis.enim@icloud.net"),
  ("Dylan Kim","Lubuskie","gravida.nunc@hotmail.net"),
  ("Jorden French","Gilgit Baltistan","ridiculus.mus@aol.org");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Olga Olsen","Pomorskie","volutpat.nulla@outlook.couk"),
  ("Zephania Guy","Gauteng","tristique.neque.venenatis@aol.org"),
  ("Jonah Davidson","Essex","est@outlook.net"),
  ("Naida Aguilar","South Island","proin.sed.turpis@yahoo.ca"),
  ("Dean Mcleod","Huádōng","eu@yahoo.net"),
  ("Malik Grimes","Valparaíso","adipiscing@icloud.edu"),
  ("Justina Sawyer","Jambi","iaculis.lacus@outlook.ca"),
  ("Wade Griffith","Phú Thọ","non.massa@outlook.ca"),
  ("Lavinia Hodges","Ulster","enim.non.nisi@google.ca"),
  ("Quemby Powell","Munster","eu.metus.in@protonmail.org");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Vivien Wilkins","Västra Götalands län","dignissim.pharetra@google.edu"),
  ("Raven Gallegos","Oyo","ut.pharetra@outlook.couk"),
  ("Fallon Moses","Dorset","ante.maecenas.mi@aol.net"),
  ("Dalton Wade","North Chungcheong","vulputate.lacus@outlook.org"),
  ("Aphrodite Tucker","Lipetsk Oblast","erat.etiam@protonmail.net"),
  ("Yasir Henry","South Island","libero.integer@google.edu"),
  ("Joshua Hill","North Sulawesi","sem@google.edu"),
  ("Marshall Hansen","Lambayeque","enim@hotmail.ca"),
  ("Jackson Lucas","Arequipa","eget@yahoo.edu"),
  ("Adrian Mcclure","Trøndelag","facilisi.sed.neque@aol.net");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Christine White","Katsina","aliquet.sem@yahoo.ca"),
  ("Oren Ayers","Tasmania","curabitur.vel@protonmail.edu"),
  ("Jaime Harding","Benue","nullam.nisl.maecenas@aol.net"),
  ("Fitzgerald Noel","Bahia","turpis.nec.mauris@hotmail.ca"),
  ("Tara Ramos","Cartago","at.auctor@outlook.edu"),
  ("Emery Nieves","South Island","vestibulum.lorem@hotmail.com"),
  ("Lyle Arnold","Caldas","sit.amet.diam@protonmail.org"),
  ("Josephine Welch","South Gyeongsang","sed.auctor@google.net"),
  ("Ryder Spence","Stockholms län","faucibus.id.libero@hotmail.ca"),
  ("Regina Sykes","Styria","donec@hotmail.ca");
INSERT INTO `cliente` (`nombre`,`region`,`email`)
VALUES
  ("Edan Byers","South Island","diam.lorem@yahoo.ca"),
  ("Gemma Hoover","Prince Edward Island","erat.nonummy@protonmail.net"),
  ("Stewart Petersen","Anglesey","sagittis.duis@aol.edu"),
  ("MacKensie Wise","Eastern Visayas","odio.auctor.vitae@protonmail.org"),
  ("Jakeem Ferrell","Himachal Pradesh","luctus.ipsum@google.ca"),
  ("Jelani Owen","Cusco","pede@protonmail.couk"),
  ("Nathaniel Craig","Cần Thơ","lacus@yahoo.org"),
  ("Karleigh Jacobson","Hessen","ante.lectus.convallis@google.net"),
  ("Henry Parker","Balochistan","lobortis.quis@yahoo.edu"),
  ("Cedric Hartman","Piura","sed@protonmail.ca");
